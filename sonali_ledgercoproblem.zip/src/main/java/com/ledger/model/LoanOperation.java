package com.ledger.model;

import lombok.Getter;

public class LoanOperation extends BankOperation {
    @Getter
    private LoanDetails loanDetails;

    public LoanOperation(Command command, BankUser bankUser, LoanDetails loanDetails) {
        super(command, bankUser);
        this.loanDetails = loanDetails;
    }

    @Override
    public void update(BankState bankState) {
        final Integer numberOfRemainingEmi = this.loanDetails.numberOfEmis();
        final Transaction transaction = Transaction.builder().emiAmount(this.loanDetails.monthlyEmiAmount())
                .numberOfTotalEmi(numberOfRemainingEmi)
                .numberOfRemainingEmi(numberOfRemainingEmi)
                .totalAmountPaid(0)
                .remainingAmountToBePaid(this.loanDetails.totalAmount())
                .build();
        bankState.setInitialStateWith(transaction);
    }
}
