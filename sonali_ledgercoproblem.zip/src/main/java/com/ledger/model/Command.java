package com.ledger.model;

public enum Command {
    LOAN,
    PAYMENT,
    BALANCE
}
